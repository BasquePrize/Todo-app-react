import React, { useState } from 'react';

const App = () => {
  const [task, setTask] = useState('');
  const [todos, setTodos] = useState([]);

  const addTask = () => {
    if (task.trim() === '') return;
    setTodos([...todos, task]);
    setTask('');
  };

  const removeTask = (index) => {
    setTodos(todos.filter((_, i) => i !== index));
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
      <h1 className="text-3xl font-bold mb-6">ToDo List</h1>
      <div className="flex space-x-2 mb-4">
        <input
          type="text"
          className="border px-4 py-2 rounded-md"
          placeholder="Enter a task"
          value={task}
          onChange={(e) => setTask(e.target.value)}
        />
        <button
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md"
          onClick={addTask}
        >
          Add
        </button>
      </div>
      <ul className="w-full max-w-md">
        {todos.map((t, index) => (
          <li
            key={index}
            className="flex justify-between items-center bg-white px-4 py-2 mb-2 shadow rounded"
          >
            <span>{t}</span>
            <button
              onClick={() => removeTask(index)}
              className="text-red-500 hover:underline"
            >
              Remove
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
