# React ToDo App

A slightly more advanced React app that allows users to add and remove tasks from a todo list.
Includes basic validation and a cleaner UI using TailwindCSS.

## Features

- Add new tasks
- Remove tasks
- Input validation
